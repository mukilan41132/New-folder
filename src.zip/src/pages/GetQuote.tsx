import React from 'react';
import "../Style/Mymoves.css";


const Get_Quotes: React.FC = () => {

  return (
    <div className='home'>     
    <div className='maincontainer'>
      <h6 className='titleText'>Get Quotes</h6>
      </div>
      </div>
  );
}

export default Get_Quotes;
