import React from 'react';
import "../Style/Mymoves.css";


const MyProfile: React.FC = () => {

  return (
    <div className='home'>     
    <div className='maincontainer'>
      <h6 className='titleText'>My Profile</h6>
      </div>
      </div>
  );
}

export default MyProfile;
