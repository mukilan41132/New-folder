import React from 'react';
import "../Style/Mymoves.css";


const Log_Out: React.FC = () => {

  return (
    <div className='home'>     
    <div className='maincontainer'>
      <h6 className='titleText'>Log Out</h6>
      </div>
      </div>
  );
}

export default Log_Out;
