import React from 'react';
import "../Style/Mymoves.css";


const InventoryTitle: React.FC = () => {

  return (
    <div className='container_divlast'>
    <span className='titleText'>Inventory Details</span>
    <div className='sub_container22'>
      <button className='button3 textDefaultSize'> Edit Inventory</button>
    </div>
  </div>
  );
}

export default InventoryTitle;
